﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Course.OOP.ProgramAbstraction.Example
{
    public class Destination
    {

        public string Name { get; set; }

    }
}
