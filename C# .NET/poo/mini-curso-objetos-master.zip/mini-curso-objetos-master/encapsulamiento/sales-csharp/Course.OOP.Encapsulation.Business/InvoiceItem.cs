﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Course.OOP.Encapsulation.Business
{
    internal class InvoiceItem
    {

        public string ProductName { get; set; }

        public decimal Amount { get; set; }

    }
}
