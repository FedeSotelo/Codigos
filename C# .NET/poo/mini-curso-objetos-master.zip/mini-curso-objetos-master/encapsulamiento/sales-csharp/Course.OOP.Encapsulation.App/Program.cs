﻿using System;

namespace Course.OOP.Encapsulation.App
{
    class Program
    {
        static void Main(string[] args)
        {
            //Course.OOP.Encapsulation.Business.
        }
    }
}
