package course.oop.encapsulation.app;

import course.oop.encapsulation.Invoice;

public class Program {

    public static void main(String[] args) {
        Invoice invoice = new Invoice();
        //invoice.addItem();
        //course.oop.encapsulation.
    }

}
