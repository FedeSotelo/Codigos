# mini-curso-objetos
Repositorio con los ejemplos de código mostrados en mi mini curso de programación profesional con objetos
