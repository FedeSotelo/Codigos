package course.oop.composition_over_inheritance.composition;

/**
 * Una instancia por cada categoría de un equipo deportivo (Sub 20, Sub 17, Mayores, etc).
 * */
public abstract class Category {
}
