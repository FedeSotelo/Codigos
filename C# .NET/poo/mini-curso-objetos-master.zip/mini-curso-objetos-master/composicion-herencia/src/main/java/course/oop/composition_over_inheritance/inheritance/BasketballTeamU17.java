package course.oop.composition_over_inheritance.inheritance;

public class BasketballTeamU17 extends BasketballTeam {
}
