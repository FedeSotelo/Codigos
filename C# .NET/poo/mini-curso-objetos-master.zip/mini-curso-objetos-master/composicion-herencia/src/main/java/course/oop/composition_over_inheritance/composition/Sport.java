package course.oop.composition_over_inheritance.composition;

public abstract class Sport {
}
