package course.oop.composition_over_inheritance.inheritance;

public class BasketballTeamU20 extends BasketballTeam {
}
