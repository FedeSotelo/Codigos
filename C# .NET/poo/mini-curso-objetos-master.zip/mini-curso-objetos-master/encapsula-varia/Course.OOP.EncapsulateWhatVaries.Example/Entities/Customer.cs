﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Course.OOP.EncapsulateWhatVaries.Example.Entities
{
    public class Customer
    {

        public string FirstName { get; set; }
        public string Email { get; set; }

    }
}
